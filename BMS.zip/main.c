#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"
#include "account.h"
#include "transaction.h"
#include "admin.h"

void restoreDatabase();
void saveTransaction(char message[]);
void viewTransactions();
void transferMoney();
void dashboard();
void changeAdminPassword();
void createDefaultPassword();
void login();
void customerLogin();

int isDuplicateAccount(int accNo);







void customerLogin()
{
    FILE *fp = fopen("accounts.dat", "rb");

    if(fp == NULL)
    {
        printf("No Account Data Found!\n");
        return;
    }

    int accNo, pin;
    Account a;
    int found = 0;

    printf("\n===== CUSTOMER LOGIN =====\n");

    printf("Account Number: ");
    scanf("%d", &accNo);

    printf("PIN: ");
    scanf("%d", &pin);

    while(fread(&a, sizeof(Account), 1, fp))
    {
        if(a.accountNumber == accNo && a.pin == pin)
        {
            found = 1;
            break;
        }
    }

    fclose(fp);

    if(!found)
    {
        printf("Invalid Account Number or PIN!\n");
        return;
    }

    printf("\nWelcome %s\n", a.name);

    int choice;

    while(1)
    {
        printf("\n===== CUSTOMER PANEL =====\n");
        printf("1. Check Balance\n");
        printf("2. Logout\n");

        printf("Enter Choice: ");
        scanf("%d", &choice);

        if(choice == 1)
        {
            printf("Current Balance: %.2f\n", a.balance);
        }
        else if(choice == 2)
        {
            break;
        }
        else
        {
            printf("Invalid Choice!\n");
        }
    }
}

int main()
{
    createDefaultPassword();

int role;

printf("\n===== BANK MANAGEMENT SYSTEM =====\n");
printf("1. Admin Login\n");
printf("2. Customer Login\n");
printf("3. Exit\n");

printf("Enter Choice: ");
scanf("%d", &role);

if(role == 1)
{
    login();
    dashboard();
}
else if(role == 2)
{
    customerLogin();
    return 0;
}
else
{
    return 0;
}

    int choice;

    while(1)
    {
        title();

  
        printf("1. Create Account\n");
        printf("2. View Accounts\n");
        printf("3. Search Account\n");
        printf("4. Deposit Money\n");
        printf("5. Withdraw Money\n");
        printf("6. Check Balance\n");
        printf("7. Delete Account\n");
        printf("8. Change PIN\n");
        printf("9. Search by Name\n");
        printf("10. Bank Statistics\n");
        printf("11. Top 5 Richest Customers\n");
        printf("12. Account Report\n");
        printf("13. Transfer Money\n");
        printf("14. View Transaction History\n");
        printf("15. Change Admin Password\n");
        printf("16. Export to CSV\n");
        printf("17. Backup Database\n");
        printf("18. Restore Database\n");
        printf("19. Exit\n");

        printf("Enter Choice: ");
        scanf("%d", &choice);

        if(choice == 1)
        {
            createAccount();
        }
        else if(choice == 2)
        {
            viewAccounts();
        }
        else if(choice == 3)
        {
            searchAccount();
        }
        else if(choice == 4)
        {
            depositMoney();
        }
        else if(choice == 5)
        {
            withdrawMoney();
        }
        else if(choice == 6)
        {
            checkBalance();
        }
        else if(choice == 7)
        {
            deleteAccount();
        }
        else if(choice == 8)
        {
            changePIN();
        }
        else if(choice == 9)
        {
            searchByName();
        }
        else if(choice == 10)
        {
            bankStatistics();
        }
        else if(choice == 11)
        {
            top5Customers();
        }
        else if(choice == 12)
        {
            accountReport();
        }
        else if(choice == 13)
        {
            transferMoney();
        }
        else if(choice == 14)
        {
            viewTransactions();
        }
        else if(choice == 15)
        {
            changeAdminPassword();
        }
        else if(choice == 16)
        {
            exportCSV();
        }
        else if(choice == 17)
        {
            backupDatabase();
        }
        else if(choice == 18)
        {
            restoreDatabase();
        }
       
        else if(choice == 19)
        {
            printf("\n=================================\n");
    printf("Thank You For Using Bank Management System\n");
    printf("=================================\n");

    break;
        }
        else
        {
            printf("Invalid Choice!\n");

            break;
        }
    }

    return 0;
}